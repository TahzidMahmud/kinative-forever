<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProxyPayment extends Model
{
    protected $table = 'proxypay_payments';
}
