@extends('frontend.layouts.app')

@section('content')
    {{-- Sliders  --}}
    @if (get_setting('home_slider_images') != null)
    <div class="home-banner-area text-white">
        <div class="aiz-carousel dots-outside-bottom mobile-img-auto-height dot-small-black " data-dots="true" data-autoplay='false'>
            @php $slider_images = json_decode(get_setting('home_slider_images'), true);  @endphp
            @foreach ($slider_images as $key => $value)
            <div class="bg-alter-10">
                <div class="carousel-box my-2 ">
                    <a href="{{ json_decode(get_setting('home_slider_links'), true)[$key] }}" class="d-block">
                        <img src="{{ uploaded_asset($value) }}" class="mw-100 w-100">
                    </a>
                </div>
            </div>

            @endforeach
        </div>
    </div>
    @endif
    @php
        $featured_categories = \App\Category::where('featured', 1)->get();
    @endphp

    @if (count($featured_categories) > 0)
    <div class="py-5">
        <div class="container">
            <div class="row row-cols-xxl-4 row-cols-lg-4 row-cols-md-4 row-cols-2 gutters-5">
                @foreach ($featured_categories as $key => $category)
                <div class="col-xl-3 col-md-6">
                    <a href="{{ route('products.category', $category->slug) }}" class="bg-white d-block mb-3 p-2  sha text-reset shadow-sm">
                        <div class="row align-items-center no-gutters">
                            <div class="col-3 text-center">
                                <img
                                    src="{{ static_asset('assets/img/placeholder.jpg') }}"
                                    data-src="{{ uploaded_asset($category->icon) }}"
                                    alt="{{ $category->getTranslation('name') }}"
                                    class="img-fluid img lazyload h-25px"
                                    onerror="this.onerror=null;this.src='{{ static_asset('assets/img/placeholder-rect.jpg') }}';"
                                >
                            </div>
                            <div class="col-7">
                                <div class="text-truncate-2 pl-3 fs-10 fw-600 text-left">{{ $category->getTranslation('name') }}</div>
                            </div>
                            <div class="col-2 text-center">
                                <i class="la la-caret-right text-secondary right-arrow fw-1000 fs-15"></i>
                            </div>
                        </div>
                    </a>
                </div>
                    @endforeach
            </div>
            {{-- old --}}
            {{-- <div class="px-md-3 px-xl-5">
                <div class="aiz-carousel gutters-10 full-outside-arrow ihw-arrow" data-items="7" data-xl-items="6" data-lg-items="5"  data-md-items="4" data-sm-items="3" data-xs-items="2" data-arrows='true'>
                    @foreach ($featured_categories as $key => $category)
                        <div class="carousel-box py-2">
                            <a href="{{ route('products.category', $category->slug) }}" class="d-block p-2 text-reset text-center hov-shadow-md rounded">
                                <span class="h-50px d-block mb-3">
                                    <img
                                        src="{{ static_asset('assets/img/placeholder.jpg') }}"
                                        data-src="{{ uploaded_asset($category->banner) }}"
                                        alt="{{ $category->getTranslation('name') }}"
                                        class="lazyload img-fluid mh-100 mx-auto"
                                        onerror="this.onerror=null;this.src='{{ static_asset('assets/img/placeholder-rect.jpg') }}';"
                                    >
                                </span>
                                <div class="text-truncate fs-11 text-uppercase fw-700 opacity-70">{{ $category->getTranslation('name') }}</div>
                            </a>
                        </div>
                    @endforeach
                </div>
            </div> --}}
        </div>
    </div>
    @endif





    {{-- Banner section 1 --}}
    @if (get_setting('home_banner1_images') != null)
    <div class="mb-5">
        <div class="container">
            <div class="row gutters-5">
                @php $banner_1_imags = json_decode(get_setting('home_banner1_images')); @endphp
                @foreach ($banner_1_imags as $key => $value)
                    <div class="col-xl col-md-6">
                        <div class="mb-3 mb-lg-0">
                            <a href="{{ json_decode(get_setting('home_banner1_links'), true)[$key] }}" class="d-block text-reset">
                                <img src="{{ static_asset('assets/img/placeholder-rect.jpg') }}" data-src="{{ uploaded_asset($banner_1_imags[$key]) }}" alt="{{ env('APP_NAME') }} promo" class="img-fluid lazyload w-100">
                            </a>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
    @endif


    {{-- Flash Deal --}}
    @php
    $flash_deal = \App\FlashDeal::where('status', 1)->where('featured', 1)->first();
    @endphp
    @if($flash_deal != null && strtotime(date('Y-m-d H:i:s')) >= $flash_deal->start_date && strtotime(date('Y-m-d H:i:s')) <= $flash_deal->end_date)
    <section class="mb-4">
    <div class="container">
        {{-- <div class="d-flex flex-wrap mb-3 align-items-center justify-content-between">
            <div>
                <h3 class="h5 fw-500 text-uppercase">
                    <span class="">{{ translate('Flash Sale') }}</span>
                </h3>
                <div class="aiz-count-down align-items-center" data-date="{{ date('Y/m/d H:i:s', $flash_deal->end_date) }}"></div>
            </div>
            <a href="{{ route('flash-deal-details', $flash_deal->slug) }}" class="d-inline-block">
                <span class="text-alter text-uppercase fs-13">{{ translate('View All') }}</span>
                <i class="las la-arrow-right size-25px bg-primary d-inline-flex ml-2 shadow-ihw justify-content-center align-items-center rounded-circle text-white"></i>
            </a>
        </div> --}}

        {{-- <div class="aiz-carousel gutters-5 dot-small-black" data-items="6" data-xl-items="5" data-lg-items="4"  data-md-items="3" data-sm-items="2" data-xs-items="2" data-dots='true' data-autoplay='true'> --}}
        <div class="row">
            <div class="col-xl-5 col-sm-3">
                <img src="{{ uploaded_asset($flash_deal->banner) }}" class="mw-100 h-100 " style="    max-height: 95%;
                width: 100%;
                object-fit: cover;"  alt="">
            </div>
            <div class="col-xl-7 col-sm-9">
                    <div class="row row-cols-lg-3 row-cols-md-3 row-cols-2  gutters-5" >
                        @foreach ($flash_deal->flash_deal_products as $key => $flash_deal_product)
                            @php
                                $product = \App\Product::find($flash_deal_product->product_id);
                            @endphp
                            @if ($product != null && $product->published != 0)
                                <div class="col mb-2">
                                    @include('frontend.partials.product_box_1',['product' => $product])
                                </div>
                            @endif
                        @endforeach
                    <div>
            </div>
        </div>
        {{-- </div> --}}
    </div>
    </section>
    @endif

    {{-- brands slider --}}
    @php $top10_brands = get_setting('top10_brands'); @endphp




    <nav>
       <div class="row">
           <div class="col " >
            <div class="nav nav-tabs d-flex justify-content-center z-1"  id="nav-tab" role="tablist" >
                <a class="nav-item nav-link opacity-40 active text-uppercase py-2 px-4 " id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true"> <h3 class="h6 fw-500 text-uppercase text-center" style="color:#1a1d1f!important;">
                   <div class="d-flex flex-column">
                        <div><img class="p-1" src="{{ static_asset("assets/img/cat_icon.png") }}" alt=""></div>
                        <span class="fw-600" style="font-family: georgia;">chosen for you</span>
                   </div>
                </h3></a>
                <a class="nav-item nav-link opacity-40 text-uppercase " id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false" style="color:#495057!important;"> <h3 class="h6 fw-500 text-uppercase text-center" >
                    <div class="d-flex flex-column">
                        <div><img class="p-1" src="{{ static_asset("assets/img/cat_icon.png") }}" alt=""></div>
                        <span class="fw-600" style="font-family: georgia;">new items</span>
                   </div>
                </h3></a>
                <a class="nav-item nav-link opacity-40 text-uppercase" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false" style="color:#495057!important;"> <h3 class="h6 fw-500 text-uppercase text-center" >
                    <div class="d-flex flex-column">
                        <div><img class="p-1" src="{{ static_asset("assets/img/cat_icon.png") }}" alt=""></div>
                        <span class="fw-600" style="font-family: georgia;">featured brands</span>
                   </div>
                </h3></a>
              </div>
           </div>
       </div>
    </nav>

    <div class="tab-content" id="nav-tabContent" style="background-image: url({{ static_asset("assets/img/yuhi_pattern.png") }});background-repeat: no-repeat;">
        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab"> {{-- Choosen categories --}}
            <div id="section_home_categories" >

           </div></div>
        <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"> {{-- Category wise Products --}}
            <div id="section_home_categories_2">

           </div></div>
        <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab"> @if ($top10_brands != null)
            <div class="mb-5  h-200px;">
                <div class="container">
                    <div class="row py-4">
                        <div class="col-md-4 col-lg-4 d-none d-lg-block d-md-block">

                        </div>
                        <div class="col-6 col-md-4 col-lg-4">
                           <div class="d-flex justify-content-center">

                           </div>
                        </div>
                        <div class="col-6 col-lg-4 col-md-4">
                            <div class="d-flex justify-content-end">
                                <a class="btn btn-primary d-flex align-items-center" style="height: 1.8rem;"  href="{{ route('products.category', $category->slug) }}" class="d-inline-block">
                                    <span class="text-alter text-uppercase text-light fs-10 px-1 py-0 my-0">{{ translate('View All') }}</span>
                                    <i class="las la-arrow-right size-25px bg-primary d-inline-flex ml-2 shadow-ihw justify-content-center align-items-center rounded-circle text-white"></i>
                                </a>
                            </div>

                        </div>
                    </div>
                    <div class="py-4">
                        <div class="aiz-carousel gutters-10 dot-small-black" data-items="8" data-xl-items="8" data-lg-items="8"  data-md-items="4" data-sm-items="2" data-xs-items="2" data-dots='true' data-arrows="false" data-infinite='false' data-autoplay='true'>
                            @php $brands = \App\Brand::latest()->limit(9)->get(); @endphp
                            @foreach ($brands as $brand)

                                @if ($brand != null)
                                <div class="carousel-box">
                                   <div class="card shadow-sm">
                                        <div class="mw-100 h-130px h-md-130px d-flex justify-content-center align-items-center">
                                            <a href="{{ route('products.brand', $brand->slug) }}" class="d-block text-reset px-2 py-2">
                                                <img src="{{ uploaded_asset($brand->logo) }}" class="img-fit lazyload mx-auto h-95px h-md-95px h-lg-95px h-xl-95px h-xxl-95px py-2 px-2">
                                            </a>
                                        </div>
                                   </div>
                                </div>
                                @endif
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
            @endif</div>
    </div>








{{-- specials --}}
    <div class="py-5 d-none">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="broadcast brush-bg bg-center display-2 pt-3 mb-0">
                    <span class="opacity-80">{{ get_setting('home_specials_title') }}</span>
                </h2>
                <div>{!! get_setting('home_specials_subtitle') !!}</div>
            </div>
            <div class="">
                @if (get_setting('home_specials_images') != null)
                    <ul class="d-flex flex-column flex-lg-row pl-0 mb-0 special-carousel align-items-center justify-content-center">
                        @foreach (json_decode(get_setting('home_specials_images'), true) as $key => $value)
                            <li class="list-inline-item mb-3">
                                <a href="{{ json_decode(get_setting('home_specials_links'), true)[$key] }}" class="text-reset d-block text-center">
                                    <img src="{{ uploaded_asset($value) }}" class="img-fluid w-100">
                                    <div class="mt-2 text-uppercase fs-12">{{ json_decode(get_setting('home_specials_labels'), true)[$key] }}</div>
                                </a>
                            </li>
                        @endforeach
                    </ul>
                @endif
            </div>
        </div>
    </div>



    {{-- Banner Section 2 --}}
    @if (get_setting('home_banner2_images') != null)
    <div class="mb-4 d-none">
        <div class="container">
            <div class="row gutters-5">
                @php $banner_2_imags = json_decode(get_setting('home_banner2_images')); @endphp
                @foreach ($banner_2_imags as $key => $value)
                    <div class="col-xl col-md-6">
                        <div class="mb-3 mb-lg-0">
                            <a href="{{ json_decode(get_setting('home_banner2_links'), true)[$key] }}" class="d-block text-reset position-relative">
                                <img src="{{ static_asset('assets/img/placeholder-rect.jpg') }}" data-src="{{ uploaded_asset($banner_2_imags[$key]) }}" alt="{{ env('APP_NAME') }} promo" class="img-fluid lazyload w-100">
                                <div class="absolute-bottom-left align-items-center d-flex justify-content-center flex-column mb-3 px-5 text-white w-100">
                                    <span class="broadcast display-4">{{ json_decode(get_setting('home_banner2_titles'), true)[$key] }}</span>
                                    <span class="mb-3">{{ json_decode(get_setting('home_banner2_sub_titles'), true)[$key] }}</span>
                                    <i class="las la-arrow-right size-25px bg-primary d-inline-flex ml-2 justify-content-center align-items-center rounded-circle text-white"></i>
                                </div>
                            </a>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
    @endif


    {{-- reviews --}}
    <div class="py-5 bg-alter-9">
        <div class="container">
            <div class="text-center mb-5">
                <div class="d-flex flex-column justify-content-center align-items-center">
                    <div><img class="p-1" src="{{ static_asset("assets/img/cat_icon.png") }}" alt=""></div>
                    <h3 class="text-uppercase text-center fs-15 fw-600" style="font-family: georgia;">{{ translate('Customer reviews') }}</h3>
                    <hr style="width: 1.3rem;color:#9f9c9f; height: 3px; background-color:#9f9c9f;padding-top:0px;padding-bottom:0px;margin-top:0px;margin-bottom:0px;" >
                </div>
            </div>
            <div>
                <div class="aiz-carousel gutters-10 dot-small-black" data-items="3" data-xl-items="3" data-lg-items="2"  data-md-items="2" data-sm-items="1" data-xs-items="1" data-dots='false' data-infinite='true'>
                    @if (get_setting('customer_reviews_image') != null)
                        @foreach (json_decode(get_setting('customer_reviews_image'), true) as $key => $value)

                            <div class="carousel-box">
                                <div class="mb-3">
                                    <div class="d-flex justify-content-start">
                                        <img src="{{ uploaded_asset($value) }}" class="size-60px rounded-review img-fit m-2">
                                        <div class=" my-4 mx-2 d-flex  flex-column">
                                            <span class="fw-900 fs-12">{{ json_decode(get_setting('customer_reviews_name'), true)[$key] }}</span>
                                            <span class="text-primary fw-600 fs-10">{{ json_decode(get_setting('customer_reviews_title'), true)[$key] }}</span>
                                        </div>
                                    </div>



                                    <div class="lh-1-8 font-italic fs-11 fw-400 my-2">{{ json_decode(get_setting('customer_reviews_details'), true)[$key] }}</div>
                                    <div class="rating rating-lg my-3">
                                        <i class="las la-star text-alter-2"></i>
                                        <i class="las la-star text-alter-2"></i>
                                        <i class="las la-star text-alter-2"></i>
                                        <i class="las la-star text-alter-2"></i>
                                        <i class="las la-star text-alter-2"></i>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    @endif
                </div>
            </div>
        </div>
    </div>

    {{-- bottom banner --}}
    @if (get_setting('bottom_banner_images') != null)
    <div class="home-banner-area text-white" style="background-color: #F7F8FA;">
        <div class="dots-inside-bottom mobile-img-auto-height dot-small-white" data-dots="false" data-autoplay='false'>
            @php $slider_images = json_decode(get_setting('bottom_banner_images'), true);  @endphp
            @foreach ($slider_images as $key => $value)
                <div class="carousel-box top-img d-flex align-items-center " style="height:420px;background-image: url({{ static_asset("assets/img/bg.png") }});  background-repeat: no-repeat;  background-size: contain;">
                    <div class="container">
                            <div class="row">
                                <div class="col-1 d-none d-lg-block d-xl-block d-md-block"></div>
                                <div class="col-md-6 col-12 text-dark d-flex align-items-center">
                                   <div class="d-flex align-items-center justify-content-center">
                                        <div class="">
                                            <h4 class="text-left move-mb text-uppercase fw-600 fs-16 my-2"  style="font-family: georgia;">{{ get_setting('topbanner_text_title') }}</h4>
                                            <div class="d-flex flex-column justify-content-start align-items-center">
                                                <p class="text-left move-mb opacity-70">{{ get_setting('topbanner_text_subtitle') }}</p>
                                            </div>
                                            <div class="">
                                                <img
                                                src="{{ static_asset('assets/img/android.png') }}"

                                                class="app-store" style="max-height: 50px;"

                                                >
                                                <img
                                                src="{{ static_asset('assets/img/apple.png') }}"

                                                class="app-store" style="max-height: 50px;"

                                                >
                                            </div>
                                        </div>
                                   </div>
                                </div>
                                <div class="col-md-5 d-none d-lg-block d-xl-block" style="height:420px;background-image: url({{ uploaded_asset($value) }});background-repeat: no-repeat;">
                                    {{-- <img src="" class="mw-100 w-100 h-100"> --}}
                                </div>

                            </div>

                    </div>
                </div>
            @endforeach
        </div>
    </div>
    @endif

{{-- about us --}}
@if(get_setting('home_about_details') != null)
<div class="bg-alter-10">
    <div class="container">
        <div class="row ">
           <div class="col-xl-1 d-none d-lg-block d-xl-block d-md-block d-sm-none"></div>
            <div class="col-xl-4 d-lg-block d-xl-block d-md-block d-sm-none">
                <img src="{{ uploaded_asset(get_setting('home_about_image')) }}" class="mw-100"  style="max-height: 100%;
                width: 100%;
                object-fit: cover;" >
            </div>
            <div class="col-xl-6 d-flex justify-content-center align-items-center">
                <div>
                    <h6 class="display-6 pt-3 mb-0 text-alter my-2 text-uppercase">
                        <span class="opacity-100 fs-16 fw-600" style="font-family: georgia;">{{ translate('About Us') }}</span>
                    </h6>
                    <div class="lh-1-8 mb-4 text-alter fs-11 fw-200">{!! get_setting('home_about_details') !!}</div>
                </div>
            </div>
        </div>
    </div>
</div>
@endif
@endsection

@section('script')
    <script>
        $(document).ready(function(){
            $.post('{{ route('home.section.home_categories') }}', {_token:'{{ csrf_token() }}'}, function(data){
                $('#section_home_categories').html(data);
                AIZ.plugins.slickCarousel();
            });

            $.post('{{ route('home.section.best_sellers') }}', {_token:'{{ csrf_token() }}'}, function(data){
                $('#section_home_categories_2').html(data);
                AIZ.plugins.slickCarousel();
            });
        });
    </script>
@endsection
