@if(get_setting('topbar_banner') != null)
<div class="position-relative top-banner removable-session z-1035 d-none" data-key="top-banner" data-value="removed">
    <a href="{{ get_setting('topbar_banner_link') }}" class="d-block text-reset">
        <img src="{{ uploaded_asset(get_setting('topbar_banner')) }}" class="w-100 mw-100 h-50px h-lg-auto img-fit">
    </a>
    <button class="btn text-white absolute-top-right set-session" data-key="top-banner" data-value="removed" data-toggle="remove-parent" data-parent=".top-banner">
        <i class="la la-close la-2x"></i>
    </button>
</div>
@endif
<!-- END Top Bar -->
<!-- Top Bar -->
<div class="top-navbar bg-primary py-10px z-1035 text-white fs-11 fw-600 d-none ">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-6 col-lg-3">
                <div class="text-left">
                    {{ get_setting('topbar_left') }}
                </div>
            </div>
            <div class="col-12 col-lg-6 text-center d-none d-lg-block ml-auto">
               <div class="container">
                    @if ( get_setting('header_menu_labels') !=  null )
                        <ul class="list-inline mb-0 pl-0 mobile-hor-swipe text-center d-flex justify-content-between align-items-center ">
                            @foreach (json_decode( get_setting('header_menu_labels'), true) as $key => $value)
                                    <li class="list-inline-item mr-0 text-white ">
                                        <a href="{{ json_decode( get_setting('header_menu_links'), true)[$key] }}" class="text-uppercase fs-11 px-1 d-inline-block  hov-opacity-100 text-reset " >
                                        <span class="menue-top"> {{ translate($value) }}</span>
                                        </a>
                                    </li>
                        @endforeach
                        </ul>
                    @endif
               </div>
            </div>
            <div class="col-6 col-lg-3 d-flex justify-content-end">
                <div class="">
                    @auth
                        @if(isAdmin())
                            <a href="{{ route('admin.dashboard') }}" class="text-reset fs-12 d-inline-block">{{ translate('My Panel')}}</a>
                        @else
                            <a href="{{ route('dashboard') }}" class="text-reset fs-12 d-inline-block">{{ translate('My Panel')}}</a>
                        @endif
                            | <a href="{{ route('logout') }}" class="text-reset fs-12 d-inline-block">{{ translate('Logout')}}</a>
                    @else
                        <a href="{{ route('user.login') }}" class="text-reset fs-12 d-inline-block">{{ translate('Login')}}</a>
                        | <a href="{{ route('user.registration') }}" class="text-reset fs-12 d-inline-block">{{ translate('Registration')}}</a>
                    @endauth
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END Top Bar -->

<header class="@if(get_setting('header_stikcy') == 'on') sticky-top @endif z-1021 bg-white border-bottom shadow-sm" >
    <div class="position-relative logo-bar-area z-1" style="background-image: url({{ static_asset("assets/img/header_patern.png") }});">
        <div class="container">
            <div class="d-flex align-items-center">

                <div class="pl-0 pr-2 d-flex align-items-center pr-xl-3 t-logo">
                    <a class="d-block py-25px mr-3 ml-0" href="{{ route('home') }}">
                        @php
                            $header_logo = get_setting('header_logo');
                        @endphp
                        @if($header_logo != null)
                            <img src="{{ uploaded_asset($header_logo) }}" alt="{{ env('APP_NAME') }}" class="mw-100 h-30px " height="15">
                        @else
                            <img src="{{ static_asset('assets/img/logo.png') }}" alt="{{ env('APP_NAME') }}" class="mw-100 h-15px" height="15">
                        @endif
                    </a>
                </div>
                {{-- category toggle for hover --}}
                {{-- <div class="h-100 d-flex align-items-center" id="category-menu-icon">
                    <div class="d-flex align-items-center navbar-light text-dark bg-alter-10 h-50px rounded-0 c-pointer px-4">
                        <span class="navbar-toggler-icon"></span>
                        <span class="text-uppercase text-dark fs-14 fw-600 px-30px">{{ translate('All Categories') }}</span>
                    </div>
                </div> --}}
                {{-- category toggle for side --}}
                <div type="button" class="mr-4 ml-0 mobile-category-trigger d-none d-lg-block" data-toggle="class-toggle" data-target=".mobile-category-sidebar">
                    <div class="navbar-light h-40px pl-2 c-pointer d-flex align-items-center justify-content-center">
                       <div class="border p-2 mr-2" style="border-radius: 5px;background-color:#ffffff;border:2px;">
                        <span class="navbar-toggler-icon  size-20px " style="color: black;"></span>
                       </div>
                        <span class="text-uppercase fs-11 fw-600 text-dark">{{ translate('All Categories') }}</span>
                    </div>
                </div>

                <div class="d-lg-none ml-auto mr-0">
                    <a class="p-1 d-block text-reset" href="javascript:void(0);" data-toggle="class-toggle" data-target=".front-header-search">
                        <i class="las la-search la-flip-horizontal la-2x"></i>
                    </a>
                </div>

                <div class="flex-grow-1 front-header-search d-flex align-items-center bg-white " style="max-width: 400px;">
                    <div class="position-relative flex-grow-1">
                        <form action="{{ route('search') }}" method="GET" class="stop-propagation">
                            <div class="d-flex position-relative align-items-center">
                                <div class="d-lg-none" data-toggle="class-toggle" data-target=".front-header-search">
                                    <button class="btn px-3" type="button"><i class="la la-2x la-long-arrow-left"></i></button>
                                </div>
                                <div class="d-flex flex-grow-1 border overflow-hidden src-br align-items-center" style="border-radius: 5px;height:2.4rem;">
                                    <input type="text" class="border-0 form-control src-input px-1" id="search" name="q" placeholder="{{translate('              Search Your Products')}}" autocomplete="off">
                                    <div class="d-none d-lg-block">
                                        <button class="btn btn-icon text-primary" type="submit">
                                            <i class="la la-search la-flip-horizontal fs-20 fw-bold "></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <div class="typed-search-box stop-propagation document-click-d-none d-none bg-white rounded shadow-lg position-absolute left-0 top-100 w-100" style="min-height: 100px">
                            <div class="search-preloader absolute-top-center">
                                <div class="dot-loader"><div></div><div></div><div></div></div>
                            </div>
                            <div class="search-nothing d-none p-3 text-center fs-16">

                            </div>
                            <div id="search-content" class="text-left">

                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-none d-lg-none ml-3 mr-0">
                    <div class="nav-search-box">
                        <a href="#" class="nav-box-link">
                            <i class="la la-search la-flip-horizontal d-inline-block nav-box-icon"></i>
                        </a>
                    </div>
                </div>
                <div class="d-flex justify-content-end ml-auto hd">
                    <div class="text-dark fw-1000 ">
                        @auth
                            @if(isAdmin())
                                <a href="{{ route('admin.dashboard') }}" class="text-reset fs-11  d-inline-block">{{ translate('My Panel')}}</a>
                            @else
                                <a href="{{ route('dashboard') }}" class="text-reset fs-11 d-inline-block">{{ translate('My Panel')}}</a>
                            @endif
                                | <a href="{{ route('logout') }}" class="text-reset fs-11 d-inline-block">{{ translate('Logout')}}</a>
                        @else
                            <a href="{{ route('user.login') }}" class="text-reset fs-11 d-inline-block">{{ translate('Login')}}</a>
                            | <a href="{{ route('user.registration') }}" class="text-reset fs-11 d-inline-block">{{ translate('Signup')}}</a>
                        @endauth
                    </div>
                </div>
                <div class="d-none d-lg-block mr-0 border-right border-left pr-3 pl-2 ml-2">
                    <div class="" id="wishlist">
                        @include('frontend.partials.wishlist')
                    </div>
                </div>

                <div class="d-none d-lg-block align-self-stretch mx-3" data-hover="dropdown">
                    <div class="nav-cart-box dropdown h-100" id="cart_items">
                        @include('frontend.partials.cart')
                    </div>
                </div>

                @if(get_setting('topbar_call_icon') || get_setting('topbar_call_text') || get_setting('topbar_call_number'))
                    <div class="d-none d-md-flex border-left pl-3 align-items-center">

                        <img src="{{ uploaded_asset(get_setting('topbar_call_icon')) }}" class="pb-1" >

                        <div class="ml-2 lh-1">
                            <div class="text-dark opacity-80 fs-13 fw-500 pb-1" style="font-family: georgia;">{{ get_setting('topbar_call_text') }}</div>
                            <div class="text-primary fw-600 fs-14">{{ get_setting('topbar_call_number') }}</div>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
</header>


{{-- for hover menue --}}
{{-- <div class="position-relative z-1020 shadow-sm">
    <div class="container">
    </div>
    <div class="hover-category-menu position-absolute w-100 top-100 left-0 right-0 d-none z-3" id="hover-category-menu">
        <div class="container">
            <div class="row gutters-10 position-relative">
                <div class="col-lg-3 position-static">
                    @include('frontend.partials.category_menu')
                </div>
            </div>
        </div>
    </div>
</div>
 --}}










